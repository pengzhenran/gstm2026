GSTM2026 data pack
Compiled 2026-10-28

Contents
--------
GSTM2026_report.md              Chinese research report
data/gstm2026_dataset.json      parsed dataset (95 abstracts, 4 withdrawn)
data/gstm2026_web_data.json     91 active abstracts + stats used by the site
data/abstracts.json             extracted abstract texts (affiliations redacted)
data/map_dots.json              11,697 land dots for the map
data/GSTM2026_programme.csv     95-row programme CSV

Licence
-------
Abstract texts: © the respective authors, licensed CC BY 4.0.
Source: https://www.gstm-2026.eu/abstract-and-programme/licence-and-copyright.html
Please retain author names, GSTM2026 abstract numbers and DOIs when reusing.

This pack does not include Copernicus website HTML, official logos/banners,
or the participant group photo.
